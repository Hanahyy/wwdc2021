
import Foundation
import PlaygroundSupport

public class SavedData {
    public var capas: String {
        get {
            var result: String? = nil
            if let keyValue = PlaygroundKeyValueStore.current["capas"], case .string(let hpType) = keyValue {
                result = hpType
            }
            return result ?? ""
        }
        set {
            PlaygroundKeyValueStore.current["capas"] = .string(newValue)
        }
    }
    
    public var tipoDaFolha: String {
        get {
            var result: String? = nil
            if let keyValue = PlaygroundKeyValueStore.current["tipoDaFolha"], case .string(let hpType) = keyValue {
                result = hpType
            }
            return result ?? ""
        }
        set {
            PlaygroundKeyValueStore.current["tipoDaFolha"] = .string(newValue)
        }
    }
    public var costura: String {
        get {
            var result: String? = nil
            if let keyValue = PlaygroundKeyValueStore.current["costura"], case .string(let hpType) = keyValue {
                result = hpType
            }
            return result ?? ""
        }
        set {
            PlaygroundKeyValueStore.current["costura"] = .string(newValue)
        }
    }
    
    public var embalagem: String {
        get {
            var result: String? = nil
            if let keyValue = PlaygroundKeyValueStore.current["embalagem"], case .string(let hpType) = keyValue {
                result = hpType
            }
            return result ?? ""
        }
        set {
            PlaygroundKeyValueStore.current["embalagem"] = .string(newValue)
        }
    }
    public var etiqueta1: String {
        get {
            var result: String? = nil
            if let keyValue = PlaygroundKeyValueStore.current["etiqueta1"], case .string(let hpType) = keyValue {
                result = hpType
            }
            return result ?? ""
        }
        set {
            PlaygroundKeyValueStore.current["etiqueta1"] = .string(newValue)
        }
    }
    
    public var etiqueta2: String {
        get {
            var result: String? = nil
            if let keyValue = PlaygroundKeyValueStore.current["etiqueta2"], case .string(let hpType) = keyValue {
                result = hpType
            }
            return result ?? ""
        }
        set {
            PlaygroundKeyValueStore.current["etiqueta2"] = .string(newValue)
        }
    }
    
    public var message: String {
        get {
            var result: String? = nil
            if let keyValue = PlaygroundKeyValueStore.current["message"], case .string(let hpType) = keyValue {
                result = hpType
            }
            return result ?? ""
        }
        set {
            PlaygroundKeyValueStore.current["message"] = .string(newValue)
        }
    }
    
}

public var savedData = SavedData()
